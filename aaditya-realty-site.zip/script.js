// ---- Business details (replace with client's real info) ----
const WHATSAPP_NUMBER = '919876543210';

// ---- Project data (prices in Lakh) ----
const img = (id, w = 900) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=75`;
const PROJECTS = [
  { name: 'Aaditya Skyline', locality: 'Hinjewadi', status: 'ongoing', bhk: [2, 3], area: '785 – 1,240', min: 78, max: 132, poss: '2027-12', rera: 'P52100054321', image: img('1574362848149-11496d93a7c7'), pop: 1 },
  { name: 'Aaditya Greens', locality: 'Wakad', status: 'ready', bhk: [1, 2], area: '520 – 890', min: 48, max: 84, poss: '2025-06', rera: 'P52100031245', image: img('1515263487990-61b07816b324'), pop: 2 },
  { name: 'Aaditya Elara', locality: 'Baner', status: 'ongoing', bhk: [3, 4], area: '1,450 – 2,300', min: 185, max: 320, poss: '2027-06', rera: 'P52100049876', image: img('1460317442991-0ec209397118'), pop: 3 },
  { name: 'Aaditya Riverside', locality: 'Kharadi', status: 'ready', bhk: [2, 3], area: '860 – 1,320', min: 92, max: 148, poss: '2025-03', rera: 'P52100028764', image: img('1582407947304-fd86f028f716'), pop: 4 },
  { name: 'Aaditya Nest', locality: 'Wagholi', status: 'upcoming', bhk: [1, 2], area: '450 – 760', min: 36, max: 62, poss: '2029-03', rera: 'Applied', image: img('1512918728675-ed5a9ecdebfd'), pop: 5 },
  { name: 'Aaditya Heights', locality: 'Kothrud', status: 'ongoing', bhk: [2, 3], area: '820 – 1,180', min: 110, max: 165, poss: '2027-03', rera: 'P52100045123', image: img('1486406146926-c627a92ad1ab'), pop: 6 },
  { name: 'Aaditya Villas', locality: 'Undri', status: 'upcoming', bhk: [4], area: '2,800 – 3,400', min: 275, max: 360, poss: '2029-09', rera: 'Applied', image: img('1613490493576-7fde63acd811'), pop: 7 },
  { name: 'Aaditya Urbania', locality: 'Hadapsar', status: 'ready', bhk: [2, 3], area: '750 – 1,150', min: 68, max: 105, poss: '2024-12', rera: 'P52100022389', image: img('1605276374104-dee2a0ed3cd6'), pop: 8 },
];
const STATUS = {
  ready: { label: 'Ready to Move', cls: 'badge-ready' },
  ongoing: { label: 'Under Construction', cls: 'badge-ongoing' },
  upcoming: { label: 'New Launch', cls: 'badge-upcoming' },
};
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// ---- Formatting ----
const fmtLakh = (l) => (l >= 100 ? `₹${+(l / 100).toFixed(2)} Cr` : `₹${l} L`);
const fmtINR = (n) => '₹' + Math.round(n).toLocaleString('en-IN');
const fmtShort = (n) => (n >= 1e7 ? `₹${+(n / 1e7).toFixed(2)} Cr` : `₹${+(n / 1e5).toFixed(1)} L`);
const fmtPoss = (p, status) => {
  if (status === 'ready') return 'Ready';
  const [y, m] = p.split('-');
  return `${MONTHS[+m - 1]} ${y}`;
};

// ---- 3D: scroll reveal + icon pop-in ----
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const revealIO = 'IntersectionObserver' in window && !reduceMotion
  ? new IntersectionObserver((entries) => entries.forEach((en) => {
      if (!en.isIntersecting) return;
      en.target.classList.add(en.target.classList.contains('icon-pop') ? 'popped' : 'in');
      revealIO.unobserve(en.target);
    }), { threshold: 0.01, rootMargin: '0px 0px -40px 0px' })
  : null;
// Safety net: anything already scrolled past is shown even if the observer missed it
window.addEventListener('scroll', () => {
  document.querySelectorAll('.reveal3d:not(.in), .icon-pop:not(.popped)').forEach((el) => {
    if (el.getBoundingClientRect().top < innerHeight * 0.9) el.classList.add('in', 'popped');
  });
}, { passive: true });
function observeReveal(el) {
  if (revealIO) revealIO.observe(el);
  else el.classList.add('in', 'popped');
}

// ---- Header ----
const header = document.getElementById('header');
const menuBtn = document.getElementById('menuBtn');
window.addEventListener('scroll', () => header.classList.toggle('scrolled', scrollY > 10), { passive: true });
menuBtn.addEventListener('click', () => {
  const open = header.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', String(open));
});
document.querySelectorAll('#nav a').forEach((a) => a.addEventListener('click', () => header.classList.remove('open')));

// ---- Filters state ----
const state = { status: new Set(), bhk: new Set(), max: 400, locality: '', sort: 'pop' };
const favs = new Set();

const localities = [...new Set(PROJECTS.map((p) => p.locality))].sort();
for (const id of ['hsLocality', 'localityFilter']) {
  const sel = document.getElementById(id);
  localities.forEach((l) => sel.add(new Option(l, l)));
}
document.querySelectorAll('[data-project-select]').forEach((sel) => PROJECTS.forEach((p) => sel.add(new Option(`${p.name}, ${p.locality}`, p.name))));
document.querySelectorAll('[data-count]').forEach((el) => {
  el.textContent = PROJECTS.filter((p) => p.status === el.dataset.count).length;
});

const cardsEl = document.getElementById('cards');
const countEl = document.getElementById('resultCount');
const budgetRange = document.getElementById('budgetRange');
const budgetVal = document.getElementById('budgetVal');
const localityFilter = document.getElementById('localityFilter');

function render() {
  let list = PROJECTS.filter((p) =>
    (!state.status.size || state.status.has(p.status)) &&
    (!state.bhk.size || p.bhk.some((b) => state.bhk.has(b))) &&
    p.min <= state.max &&
    (!state.locality || p.locality === state.locality)
  );
  const sorters = {
    pop: (a, b) => a.pop - b.pop,
    low: (a, b) => a.min - b.min,
    high: (a, b) => b.max - a.max,
    poss: (a, b) => a.poss.localeCompare(b.poss),
  };
  list = list.sort(sorters[state.sort]);
  countEl.textContent = list.length;

  if (!list.length) {
    cardsEl.innerHTML = `<div class="empty"><h3>No projects match these filters</h3><p>Try a higher budget or a different locality.</p><button class="btn btn-outline btn-sm" onclick="clearFilters()">Clear filters</button></div>`;
    return;
  }

  cardsEl.innerHTML = list.map((p) => {
    const s = STATUS[p.status];
    const bhk = p.bhk.length > 1 ? `${p.bhk.join(', ')} BHK` : p.bhk[0] === 4 ? '4 BHK Villa' : `${p.bhk[0]} BHK`;
    return `
    <article class="card reveal3d" data-tilt="6">
      <div class="card-media">
        <img loading="lazy" src="${p.image}" alt="${p.name}, ${p.locality}">
        <span class="badge ${s.cls}">${s.label}</span>
        <span class="rera"><svg class="icon"><use href="#i-shield"/></svg> RERA: ${p.rera}</span>
        <button class="fav ${favs.has(p.name) ? 'on' : ''}" data-fav="${p.name}" aria-label="Shortlist ${p.name}" aria-pressed="${favs.has(p.name)}"><svg class="icon"><use href="#i-heart"/></svg></button>
      </div>
      <div class="card-body">
        <div class="card-price">${fmtLakh(p.min)} – ${fmtLakh(p.max)} <small>onwards*</small></div>
        <h3 class="card-title">${p.name}</h3>
        <div class="card-loc"><svg class="icon"><use href="#i-pin"/></svg> ${p.locality}, Pune</div>
        <div class="card-specs">
          <div>Config<strong>${bhk}</strong></div>
          <div>Carpet<strong>${p.area} ft²</strong></div>
          <div>Possession<strong>${fmtPoss(p.poss, p.status)}</strong></div>
        </div>
        <div class="card-actions">
          <button class="btn btn-outline btn-sm" data-enquire="${p.name}" data-intent="price">Get Price Sheet</button>
          <button class="btn btn-accent btn-sm" data-enquire="${p.name}" data-intent="visit">Site Visit</button>
          <a class="btn btn-wa btn-sm" href="#" data-wa="${p.name}" aria-label="WhatsApp about ${p.name}"><svg class="icon"><use href="#i-wa"/></svg></a>
        </div>
      </div>
    </article>`;
  }).join('');
  cardsEl.querySelectorAll('.reveal3d').forEach((el, i) => { el.style.setProperty('--d', `${(i % 2) * 0.1}s`); observeReveal(el); });
}

function syncControls() {
  document.querySelectorAll('input[name="status"]').forEach((c) => (c.checked = state.status.has(c.value)));
  document.querySelectorAll('.bhk-chip').forEach((c) => c.classList.toggle('active', state.bhk.has(+c.dataset.bhk)));
  budgetRange.value = state.max;
  budgetVal.textContent = state.max >= 400 ? 'Any' : `Up to ${fmtLakh(state.max)}`;
  localityFilter.value = state.locality;
}

function clearFilters() {
  state.status.clear(); state.bhk.clear(); state.max = 400; state.locality = '';
  syncControls(); render();
}
window.clearFilters = clearFilters;

document.querySelectorAll('input[name="status"]').forEach((c) => c.addEventListener('change', () => {
  c.checked ? state.status.add(c.value) : state.status.delete(c.value);
  render();
}));
document.querySelectorAll('.bhk-chip').forEach((c) => c.addEventListener('click', () => {
  const b = +c.dataset.bhk;
  state.bhk.has(b) ? state.bhk.delete(b) : state.bhk.add(b);
  syncControls(); render();
}));
budgetRange.addEventListener('input', () => { state.max = +budgetRange.value; syncControls(); render(); });
localityFilter.addEventListener('change', () => { state.locality = localityFilter.value; render(); });
document.getElementById('sortBy').addEventListener('change', (e) => { state.sort = e.target.value; render(); });
document.getElementById('clearFilters').addEventListener('click', clearFilters);

// Mobile filter drawer
const filtersEl = document.getElementById('filters');
document.getElementById('openFilters').addEventListener('click', () => filtersEl.classList.add('open'));
['closeFilters', 'applyFilters'].forEach((id) => document.getElementById(id).addEventListener('click', () => filtersEl.classList.remove('open')));

// ---- Hero search ----
let heroStatus = 'all';
document.querySelectorAll('.search-tab').forEach((t) => t.addEventListener('click', () => {
  document.querySelectorAll('.search-tab').forEach((x) => x.classList.toggle('active', x === t));
  heroStatus = t.dataset.status;
}));
function applySearch({ status, bhk, locality, max }) {
  state.status = new Set(status && status !== 'all' ? [status] : []);
  state.bhk = new Set(bhk ? [+bhk] : []);
  state.locality = locality || '';
  state.max = max || 400;
  syncControls(); render();
  document.getElementById('projects').scrollIntoView();
}
document.getElementById('heroSearch').addEventListener('submit', (e) => {
  e.preventDefault();
  applySearch({
    status: heroStatus,
    bhk: document.getElementById('hsBhk').value,
    locality: document.getElementById('hsLocality').value,
    max: +document.getElementById('hsBudget').value,
  });
});
document.querySelectorAll('[data-quick]').forEach((c) => c.addEventListener('click', () => {
  const [bhk, locality] = c.dataset.quick.split('|');
  applySearch({ bhk, locality });
}));
document.querySelectorAll('[data-footer-status]').forEach((a) => a.addEventListener('click', () => applySearch({ status: a.dataset.footerStatus })));

// ---- Shortlist ----
cardsEl.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-fav]');
  if (!btn) return;
  const name = btn.dataset.fav;
  favs.has(name) ? favs.delete(name) : favs.add(name);
  btn.classList.toggle('on', favs.has(name));
  btn.classList.remove('burst'); void btn.offsetWidth; btn.classList.add('burst');
  btn.setAttribute('aria-pressed', String(favs.has(name)));
});

// ---- WhatsApp links ----
const waLink = (project) => {
  const msg = project ? `Hi, I'm interested in ${project}. Please share price and availability.` : "Hi, I'd like to know more about your projects.";
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
};
document.addEventListener('click', (e) => {
  const a = e.target.closest('[data-wa]');
  if (!a) return;
  e.preventDefault();
  window.open(waLink(a.dataset.wa), '_blank', 'noopener');
});

// ---- Featured: gallery + tabs ----
const galleryMain = document.getElementById('galleryMain');
document.querySelectorAll('#galleryThumbs button').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('#galleryThumbs button').forEach((x) => x.classList.toggle('active', x === b));
  galleryMain.src = b.dataset.src;
  galleryMain.alt = b.querySelector('img').alt;
}));
document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === t));
  document.querySelectorAll('.tab-panel').forEach((p) => (p.hidden = p.dataset.panel !== t.dataset.tab));
}));

// ---- EMI calculator ----
const loanAmt = document.getElementById('loanAmt');
const loanRate = document.getElementById('loanRate');
const loanYears = document.getElementById('loanYears');
function calcEmi() {
  const P = +loanAmt.value, r = +loanRate.value / 12 / 100, n = +loanYears.value * 12;
  const emi = (P * r * (1 + r) ** n) / ((1 + r) ** n - 1);
  const total = emi * n;
  document.getElementById('loanAmtOut').textContent = fmtShort(P);
  document.getElementById('loanRateOut').textContent = `${(+loanRate.value).toFixed(2)}%`;
  document.getElementById('loanYearsOut').textContent = `${loanYears.value} years`;
  document.getElementById('emiAmt').textContent = fmtINR(emi);
  document.getElementById('emiPrincipal').textContent = fmtINR(P);
  document.getElementById('emiInterest').textContent = fmtINR(total - P);
  document.getElementById('emiTotal').textContent = fmtINR(total);
  document.getElementById('emiBar').style.width = `${(P / total) * 100}%`;
}
[loanAmt, loanRate, loanYears].forEach((i) => i.addEventListener('input', calcEmi));
calcEmi();

// ---- Forms ----
function validate(form) {
  let ok = true;
  const setErr = (input, msg) => {
    const field = input.closest('.field');
    field.classList.toggle('invalid', !!msg);
    field.querySelector('.field-error').textContent = msg || '';
    if (msg) ok = false;
  };
  const name = form.elements.name, phone = form.elements.phone;
  setErr(name, name.value.trim().length < 2 ? 'Please enter your name' : '');
  setErr(phone, /^[6-9]\d{9}$/.test(phone.value.trim()) ? '' : 'Enter a valid 10-digit mobile number');
  return ok;
}
document.querySelectorAll('input[name="phone"]').forEach((i) => i.addEventListener('input', () => (i.value = i.value.replace(/\D/g, ''))));

function showSuccess(container, form) {
  const project = form.elements.project.value;
  const name = form.elements.name.value.trim().split(' ')[0];
  container.innerHTML = `
    <div class="form-success">
      <span class="stat-icon"><svg class="icon"><use href="#i-check"/></svg></span>
      <h3>Thank you, ${name.replace(/[<>&"]/g, '')}!</h3>
      <p>Our sales team will call you within 30 minutes during working hours.</p>
      <a href="#" class="btn btn-wa" data-wa="${project}"><svg class="icon"><use href="#i-wa"/></svg> Chat on WhatsApp now</a>
    </div>`;
}

// NOTE: no backend yet — connect this to the client's CRM / email / Google Sheet.
document.getElementById('mainForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if (validate(e.target)) showSuccess(document.getElementById('mainFormCard'), e.target);
});

// ---- Enquiry modal ----
const modal = document.getElementById('modal');
const modalCard = modal.querySelector('.modal-card');
const modalFormHTML = modalCard.innerHTML;
const INTENTS = {
  brochure: ['Download Brochure', 'Enter your details to get the brochure on WhatsApp.', 'Get Brochure'],
  visit: ['Book a Free Site Visit', 'Free pick-up & drop. Choose a time that suits you.', 'Book Site Visit'],
  price: ['Get Price Sheet', 'Latest price list, floor plans & offers.', 'Get Price Sheet'],
  loan: ['Home Loan Assistance', 'Get the best rates from 15+ partner banks.', 'Request Callback'],
};
function openModal(project, intent) {
  modalCard.innerHTML = modalFormHTML;
  const [title, sub, cta] = INTENTS[intent] || ['Enquire Now', 'Get price sheet, floor plans & current offers.', 'Submit'];
  modal.querySelector('#modalTitle').textContent = project ? `${title} — ${project}` : title;
  modal.querySelector('#modalSub').textContent = sub;
  modal.querySelector('#modalSubmit').textContent = cta;
  const sel = modal.querySelector('#m-project');
  if (!sel.options.length || sel.options.length === 1) PROJECTS.forEach((p) => sel.add(new Option(`${p.name}, ${p.locality}`, p.name)));
  sel.value = project || '';
  modal.querySelector('#m-phone').addEventListener('input', (e) => (e.target.value = e.target.value.replace(/\D/g, '')));
  modal.querySelector('#modalForm').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!validate(e.target)) return;
    const wrap = document.createElement('div');
    modalCard.querySelector('form').replaceWith(wrap);
    showSuccess(wrap, e.target);
  });
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(() => modal.querySelector('#m-name')?.focus(), 50);
}
function closeModal() {
  modal.classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-enquire]');
  if (b) { e.preventDefault(); openModal(b.dataset.enquire, b.dataset.intent); return; }
  if (e.target.closest('[data-close]')) closeModal();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

render();

// ---- 3D: tag static elements for reveal / icon pop ----
document.querySelectorAll('.why-card, .tcard').forEach((el) => el.setAttribute('data-tilt', '10'));
document.querySelector('.gallery-main').setAttribute('data-tilt', '5');
document.querySelectorAll('.why-card, .tcard, .stats-grid, .emi, .form-card:not(.modal-card), .gallery-main, .key-facts')
  .forEach((el) => {
    el.classList.add('reveal3d');
    const siblings = [...el.parentElement.children].filter((s) => s.classList.contains('reveal3d'));
    el.style.setProperty('--d', `${siblings.indexOf(el) * 0.1}s`);
    observeReveal(el);
  });
document.querySelectorAll('.stat .stat-icon, .why-card .stat-icon, .amenity .icon, .socials a, .enquiry-points .icon')
  .forEach((el) => {
    el.classList.add('icon-pop');
    const group = [...el.closest('.stats-grid, .why, .amenities, .socials, .enquiry-points').querySelectorAll('.icon-pop')];
    el.style.setProperty('--d', `${group.indexOf(el) * 0.08 + 0.15}s`);
    observeReveal(el);
  });
// Amenities live in a hidden tab: replay their pop when the tab opens
document.querySelector('.tab[data-tab="amenities"]').addEventListener('click', () => {
  document.querySelectorAll('.amenity .icon').forEach((el) => {
    el.classList.remove('popped'); void el.getBoundingClientRect(); el.classList.add('popped');
  });
});

// ---- 3D: mouse tilt (desktop pointers only) ----
if (!reduceMotion && matchMedia('(hover: hover) and (pointer: fine)').matches) {
  let active = null;
  const reset = (el) => {
    el.classList.remove('tilting');
    el.style.setProperty('--rx', '0deg');
    el.style.setProperty('--ry', '0deg');
  };
  document.addEventListener('pointermove', (e) => {
    const el = e.target.closest('[data-tilt]');
    if (active && active !== el) reset(active);
    active = el;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = (e.clientY - r.top) / r.height;
    const max = +el.dataset.tilt || 8;
    el.classList.add('tilting');
    el.style.setProperty('--ry', `${((x - 0.5) * 2 * max).toFixed(2)}deg`);
    el.style.setProperty('--rx', `${((0.5 - y) * 2 * max).toFixed(2)}deg`);
    el.style.setProperty('--mx', `${x * 100}%`);
    el.style.setProperty('--my', `${y * 100}%`);
  }, { passive: true });
  document.addEventListener('mouseout', (e) => { if (!e.relatedTarget && active) { reset(active); active = null; } });

  // Hero parallax: background drifts against the mouse and on scroll
  const hero = document.querySelector('.hero');
  const heroImg = document.querySelector('.hero-bg img');
  let mx = 0, my = 0, ticking = false;
  const paint = () => {
    const sy = Math.min(scrollY, hero.offsetHeight);
    heroImg.style.transform = `scale(1.12) translate3d(${mx * -18}px, ${my * -12 + sy * 0.25}px, 0)`;
    ticking = false;
  };
  const queue = () => { if (!ticking) { ticking = true; requestAnimationFrame(paint); } };
  hero.addEventListener('pointermove', (e) => {
    const r = hero.getBoundingClientRect();
    mx = (e.clientX - r.left) / r.width - 0.5;
    my = (e.clientY - r.top) / r.height - 0.5;
    queue();
  }, { passive: true });
  window.addEventListener('scroll', queue, { passive: true });
}
